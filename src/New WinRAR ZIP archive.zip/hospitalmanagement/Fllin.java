/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospitalmanagement;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Aya121298
 */
public class Fllin {
  MyConnection my_con = new MyConnection();
    
      public boolean AddMe (String Fname, String Phone, String Email, String Complain ){
        PreparedStatement ps;
        
        String AddQuery = "INSERT INTO `patient`( `Full Name`, `Phone.no`, `E-mail`,`Complain`) VALUES (?,?,?,?)";      
        try {
            ps= my_con.createConnection().prepareStatement(AddQuery);
            
            ps.setString(1, Fname);
           
            ps.setString(2, Phone);
           ps.setString(3, Email);
           ps.setString(4,Complain);
        return (ps.executeUpdate()>0);
            
        
                
                
        } catch (SQLException ex) {
            Logger.getLogger(Patients.class.getName()).log(Level.SEVERE, null, ex);                                                 
            return false;
        }   
    } 
      
    public boolean EditMe (String Complain,String Fname,String Phone, String Email ){
        PreparedStatement ps;
       
        String editQuery = "UPDATE `patient` SET `Phone.no`=?,`E-mail`=? , `Complain`=?  WHERE `Full Name`=?";      
        try {
            ps= my_con.createConnection().prepareStatement(editQuery);
            
            ps.setString(1, Fname);
            
            ps.setString(2, Phone);
            ps.setString(3, Email);
            
            ps.setString(4, Complain);
       
            
                return (ps.executeUpdate()>0);
            
                
                
        } catch (SQLException ex) {
            Logger.getLogger(Fllin.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }   
    }   
   }
