/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospitalmanagement;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Aya121298
 */
public class DiagANDpres {
    MyConnection con = new MyConnection();
    
   public boolean AddDiag (String Diagnosis, String prescription ){
        PreparedStatement ps;
        
        String AddQuery = "INSERT INTO `patient`(`Diagnosis`, `Prescription`) VALUES (?,?) WHERE ID=?";      
        try {
            ps= con.createConnection().prepareStatement(AddQuery);
          
            ps.setString(2, Diagnosis);
            ps.setString(3,prescription );
    
          
        return (ps.executeUpdate()>0);
            
        
                
                
        } catch (SQLException ex) {
            Logger.getLogger(Patients.class.getName()).log(Level.SEVERE, null, ex);                                                 
            return false;
        }   
    }
    
     public boolean EditDiag (int ID,String Diagnosis, String prescription ){
        PreparedStatement ps;
       
        String editQuery = "UPDATE `patient` SET `Diagnosis`=?,`Prescription`=? WHERE `ID`=?";      
        try {
            ps= con.createConnection().prepareStatement(editQuery);
            
            ps.setString(1, Diagnosis);
            ps.setString(2, prescription);
         
            ps.setInt(3, ID);
           
            
                return (ps.executeUpdate()>0);
            
                
                
        } catch (SQLException ex) {
            Logger.getLogger(Patients.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }   
    } 
}
