/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospitalmanagement;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author hp
 */
public class Patients {
    MyConnection my_con = new MyConnection();
    
     
    public boolean EditPatient (int ID,String Fname,String Phone, String Email ){
        PreparedStatement ps;
       
        String editQuery = "UPDATE `patient` SET `Full Name`=?,`Phone.no`=?,`E-mail`=?   WHERE `ID`=?";      
        try {
            ps= my_con.createConnection().prepareStatement(editQuery);
            
            ps.setString(1, Fname);
            
            ps.setString(2, Phone);
            ps.setString(3, Email);
            
            ps.setInt(4, ID);
       
            
                return (ps.executeUpdate()>0);
            
                
                
        } catch (SQLException ex) {
            Logger.getLogger(Patients.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }   
    }
    

    
    public boolean RemovePatient (int ID){
      PreparedStatement ps;
       
        String deleteQuery = "DELETE FROM `patient` WHERE `ID`=?";      
        try {
            ps= my_con.createConnection().prepareStatement(deleteQuery);
            
            
            ps.setInt(1, ID);
           
            
                return (ps.executeUpdate()>0);
            
                
                
        } catch (SQLException ex) {
            Logger.getLogger(Patients.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }     
    }
   public void FillJTable (JTable table){
       PreparedStatement ps;
       ResultSet rs;
       String selectQuery = "SELECT * FROM patient";
       
        try {
            ps = my_con.createConnection().prepareStatement(selectQuery);
            
            rs= ps.executeQuery();
            DefaultTableModel tableModel = (DefaultTableModel)table.getModel();
            
            Object [] row;
            while (rs.next()){
                row = new Object [5];
                row[0] = rs.getInt(1);
                row[1]= rs.getString(2);
                row[2]= rs.getInt(3);
                row[3]= rs.getString(4);
                row[4]= rs.getString(7);
               tableModel.addRow(row); 
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Patients.class.getName()).log(Level.SEVERE, null, ex);
        
        }
           
   } 
}
