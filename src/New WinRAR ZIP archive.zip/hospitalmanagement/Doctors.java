/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospitalmanagement;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author hp
 */
public class Doctors {
   MyConnection my_con = new MyConnection();
 
  
 public boolean AddDoctor ( String DoctorName, String PhoneNumber, String RoomNumber){
PreparedStatement ps;
        
        String AddQuery = "INSERT INTO `specification`( `Doctor Name`,`Phone Number`,`Room Number`) VALUES (?,?,?)";      
        try {
            ps= my_con.createConnection().prepareStatement(AddQuery);
            
            
            
             ps.setString(1, DoctorName);
            ps.setString(2, PhoneNumber);
            ps.setString(3,RoomNumber);
        return (ps.executeUpdate()>0);
            
        
                
                
        } catch (SQLException ex) {
            Logger.getLogger(Doctors.class.getName()).log(Level.SEVERE, null, ex);                                                 
            return false;
        }   
    }  
 public boolean EditDoctor (int ID,String DoctorName, String PhoneNumber, String RoomNumber){
PreparedStatement ps;
        
        String EditQuery = "UPDATE `specification` SET `Doctor Name`=?,`Phone Number`=?,`Room Number`=? WHERE `ID`=? ";      
        try {
            ps= my_con.createConnection().prepareStatement(EditQuery);
            
         
           
            ps.setString(1, DoctorName);
            ps.setString(2, PhoneNumber);
            ps.setString(3, RoomNumber);
            ps.setInt(4, ID);
        return (ps.executeUpdate()>0);
            
        
                
                
        } catch (SQLException ex) {
            Logger.getLogger(Doctors.class.getName()).log(Level.SEVERE, null, ex);                                                 
            return false;
        }   
    }  
 
  public boolean RemoveDoctor (int ID){
      PreparedStatement ps;
       
        String deleteQuery = "DELETE FROM `specification` WHERE `ID`=?";      
        try {
            ps= my_con.createConnection().prepareStatement(deleteQuery);
            
            
            ps.setInt(1,ID);
           
            
                return (ps.executeUpdate()>0);
            
                
                
        } catch (SQLException ex) {
            Logger.getLogger(Doctors.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }     
    }
   public void FillJTable1 (JTable table){
       PreparedStatement ps;
       ResultSet rs;
       String selectQuery = "SELECT * FROM specification ";
        
        try {
            ps = my_con.createConnection().prepareStatement(selectQuery);
           
          
            rs= ps.executeQuery();
            DefaultTableModel tableModel = (DefaultTableModel)table.getModel();
            
            Object [] row;
            while (rs.next()){
                row = new Object [4];
                
                row[0]= rs.getInt(1);
               
                row[1]= rs.getString(2);
                row[2]= rs.getString(3);
                row[3]= rs.getString(4);
                
               tableModel.addRow(row); 
               
            }
           

TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(tableModel);
   table.setRowSorter(sorter);
            
        } catch (SQLException ex) {
            Logger.getLogger(Doctors.class.getName()).log(Level.SEVERE, null, ex);
        
        }
               
   } 
   
}


